import { onlineEducationInstitutions } from "../data/onlineEducationInstitutions.js";
import onlineEducationHeroVideo from "../assets/images/online-education-hero.mp4";
import onlineEducationHeroPoster from "../assets/images/online-education-hero.jpg";

const levels = ["School", "Diploma", "Certificate", "Undergraduate", "Bachelor's", "Postgraduate", "Master's", "MBA", "PhD / Doctorate", "Online Degree", "Short Course", "Professional Certificate", "Microcredential"];
const subjects = ["AI & Machine Learning", "Data Science", "Business", "Engineering", "Healthcare", "Finance", "Digital Marketing", "Cybersecurity", "Design", "Psychology", "Education"];

export default function OnlineEducationPage() {
    return `
      <main class="oe-page" id="online-education-page">
        <nav class="oe-nav" aria-label="Online education sections">
          <div class="oe-nav-inner">
            <a class="oe-brand" href="#oe-top">EC <span>| ONLINE EDUCATION</span>
            </a>
            <button class="oe-menu-toggle" id="oe-menu-toggle" type="button" aria-expanded="false" aria-controls="oe-nav-links">Menu</button>
            <div class="oe-nav-links" id="oe-nav-links">
              <a href="#oe-programmes">Courses</a>
              <details class="oe-nav-dropdown">
                <summary>Study paths <span aria-hidden="true">⌄</span></summary>
                <div class="oe-nav-dropdown-menu">
                  <a href="#oe-school">School learning</a>
                  <a href="#oe-levels">Diplomas &amp; certificates</a>
                  <a href="#oe-degrees">Bachelor’s &amp; master’s</a>
                </div>
              </details>
              <a href="#oe-universities">Universities</a>
              <a href="#oe-programmes">Compare</a>
              <a href="/online-education/admin">Admin</a>
              <a class="oe-nav-cta" href="#oe-programmes">Find a course <span aria-hidden="true">↗</span>
            </a>
            </div>
          </div>
        </nav>
        <section class="oe-hero" id="oe-top">
          <video class="oe-hero-video" autoplay muted loop playsinline preload="metadata" poster="${onlineEducationHeroPoster}" aria-hidden="true" tabindex="-1">
            <source src="${onlineEducationHeroVideo}" type="video/mp4">
          </video>
          <div class="oe-hero-inner">
            <div class="oe-hero-copy">
            <p class="oe-eyebrow">A clearer way to choose what’s next</p>
            <h1>Online Education: Compare Courses, Certificates &amp; Degrees</h1>
            <p>Compare online courses, certificates, diplomas and degree programmes from learning websites and universities. Explore options by subject, education level and study mode, then verify fees and recognition with the provider.</p>
            <div class="oe-hero-actions">
            <a class="oe-button oe-primary" href="#oe-programmes">Explore Programmes <span>→</span>
            </a>
            <a class="oe-button oe-outline" href="#oe-programmes">Compare Courses</a>
            </div>
            <div class="oe-quick">
            <span>Popular:</span>${["Computer Science", "Artificial Intelligence", "Data Science", "Business & Management", "Digital Marketing", "Healthcare", "Engineering", "Psychology"].map(x=>`<button type="button" data-query="${x}">${x}</button>`).join("")}</div>
            </div>
          </div>
        </section>
        <section class="oe-section oe-level-section" id="oe-levels">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">LEARNING FOR EVERY STAGE</p>
            <h2>Explore by education level</h2>
            <p>From self-paced study resources to postgraduate pathways.</p>
            </div>
            <a class="oe-text-link" href="#oe-programmes">Browse all options →</a>
            </div>
            <div class="oe-level-carousel" aria-label="Education levels">
            <div class="oe-level-grid">${[["01","School learning","Subject-led practice and learning resources.","School","⌂"],["02","Diploma programmes","Explore vocational and academic study routes.","Diploma","▤"],["03","Bachelor’s degrees","Discover undergraduate learning pathways.","Bachelor's","◇"],["04","Master’s degrees","Explore advanced postgraduate study.","Master's","✦"],["05","MBA programmes","Find business and management study options.","MBA","↗"],["06","PhD & doctoral","Explore research-led doctoral pathways.","PhD / Doctorate","⌘"],["07","Online degrees","Browse degree discovery resources.","Online Degree","▣"],["08","Professional certificates","Build knowledge through focused programmes.","Professional Certificate","✳"],["09","Short courses","Learn a subject in a shorter format.","Short Course","◷"],["10","Microcredentials","Explore compact learning achievements.","Microcredential","✣"]].map(([n,t,d,l,i])=>`<a class="oe-level-card" href="#oe-programmes" data-level="${l}">
            <span class="oe-card-icon">${i}</span>
            <span class="oe-card-number">${n}</span>
            <span class="oe-level-photo" aria-hidden="true">
            </span>
            <h3>${t}</h3>
            <p>${d}</p>
            <span class="oe-card-arrow">Explore options →</span>
            </a>`).join("")}</div>
            </div>
            </div>
            </section>
        <section class="oe-section oe-subject-section">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">FOLLOW YOUR CURIOSITY</p>
            <h2>Explore by subject</h2>
            <p>Choose a subject to apply it to the programme results.</p>
            </div>
            <div class="oe-subject-controls" aria-label="Subject carousel controls">
            <button class="oe-subject-arrow" type="button" data-subject-prev aria-label="Previous subjects">←</button>
            <button class="oe-subject-arrow" type="button" data-subject-next aria-label="Next subjects">→</button>
            </div>
            </div>
            <div class="oe-subject-carousel" data-subject-carousel>
            <div class="oe-subject-grid" data-subject-track>${subjects.map((s,i)=>`<button class="oe-subject-card" type="button" data-subject="${s}">
            <span class="oe-subject-art" aria-hidden="true">
            </span>
            <span class="oe-subject-icon">${["✦","▥","↗","⚙","＋","＄","◉","◇","✎","◎","▧"][i]}</span>
            <b>${s}</b>
            <small>Explore programmes <i>→</i>
            </small>
            </button>`).join("")}</div>
            </div>
            </div>
            </section>
        <section class="oe-section oe-popular" id="oe-popular">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">A FEW PLACES TO START</p>
            <h2>Popular online course topics</h2>
            <p>Illustrative discovery links to official topic catalogues. Courses remain hosted by their providers.</p>
            </div>
            <a class="oe-text-link" href="#oe-programmes">View all discovery options →</a>
            </div>
            <div class="oe-popular-grid">${[["Foundations of Computer Science","Computer Science & IT","Short Course","Self-paced","Computer Science","https://www.coursera.org/browse/computer-science"],["Introduction to Artificial Intelligence","Artificial Intelligence","Professional Certificate","Check provider website","AI & Machine Learning","https://www.edx.org/learn/artificial-intelligence"],["Data Analysis Essentials","Data Science","Certificate","Check provider website","Data Science","https://www.coursera.org/browse/data-science"],["Business and Management: Core Concepts","Business & Management","Short Course","Check provider website","Business","https://www.futurelearn.com/subjects/business-and-management-courses"]].map(([title,subject,level,duration,filter,url])=>`<article class="oe-popular-card">
            <span class="oe-provider-mark" aria-hidden="true">${subject.slice(0,2).toUpperCase()}</span>
            <p class="oe-programme-subject">${subject}</p>
            <h3>${title}</h3>
            <div class="oe-programme-tags">
            <span>${level}</span>
            <span>${duration}</span>
            </div>
            <p class="oe-card-footnote">Illustrative topic link · no fee or certificate claim.</p>
            <div class="oe-popular-actions">
            <a href="${url}" target="_blank" rel="noopener noreferrer">Browse provider topic ↗</a>
            <button type="button" data-query="${filter}">Find similar options →</button>
            </div>
            </article>`).join("")}</div>
            </div>
            </section>
        <section class="oe-section oe-platform-guide" id="oe-platforms" aria-labelledby="oe-platform-title">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">A GUIDE TO DISCOVERY SOURCES</p>
            <h2 id="oe-platform-title">Best websites for online learning, by education level</h2>
            <p>Find learning websites for school courses, diplomas, certificates and online degrees. There is no single best site for everyone, so compare course choice, format, cost and recognition before choosing. Confirm current details with each provider.</p>
            </div>
            <a class="oe-text-link" href="#oe-programmes">Explore EduConnect options →</a>
            </div>
            <div class="oe-platform-grid">
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">01 · SCHOOL</span>
            <h3>School</h3>
            <p>Find subject-led lessons, practice resources and short courses for school-age learners.</p>
            <div class="oe-platform-links">
            <a href="https://www.coursera.org/" target="_blank" rel="noopener noreferrer">
            <b>Coursera</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.khanacademy.org/" target="_blank" rel="noopener noreferrer">
            <b>Khan Academy</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.futurelearn.com/" target="_blank" rel="noopener noreferrer">
            <b>FutureLearn</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="School">Explore school options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">02 · COLLEGE DIPLOMA</span>
            <h3>College Diploma</h3>
            <p>Explore course and provider catalogues for diploma-level study options.</p>
            <div class="oe-platform-links">
            <a href="https://www.coursera.org/" target="_blank" rel="noopener noreferrer">
            <b>Coursera</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.edx.org/" target="_blank" rel="noopener noreferrer">
            <b>edX</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="Diploma">Explore diploma options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">03 · BACHELOR’S</span>
            <h3>Bachelor’s</h3>
            <p>Compare undergraduate discovery listings, then verify awards and entry requirements.</p>
            <div class="oe-platform-links">
            <a href="https://www.studyportals.com/" target="_blank" rel="noopener noreferrer">
            <b>Studyportals</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.distancelearningportal.com/" target="_blank" rel="noopener noreferrer">
            <b>DistanceLearningPortal</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="Bachelor's">Explore bachelor’s options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">04 · MASTER’S</span>
            <h3>Master’s</h3>
            <p>Search postgraduate opportunities and confirm format, fees and requirements with institutions.</p>
            <div class="oe-platform-links">
            <a href="https://www.studyportals.com/" target="_blank" rel="noopener noreferrer">
            <b>Studyportals</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.distancelearningportal.com/" target="_blank" rel="noopener noreferrer">
            <b>DistanceLearningPortal</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="Master's">Explore master’s options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">05 · DOCTORAL STUDY</span>
            <h3>PhD</h3>
            <p>Discover doctoral pathways and check research fit, supervision and admissions with each university.</p>
            <div class="oe-platform-links">
            <a href="https://www.studyportals.com/" target="_blank" rel="noopener noreferrer">
            <b>Studyportals</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.distancelearningportal.com/" target="_blank" rel="noopener noreferrer">
            <b>DistanceLearningPortal</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="PhD / Doctorate">Explore doctoral options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">06 · ONLINE DEGREES</span>
            <h3>Online Degrees</h3>
            <p>Explore degree discovery services and provider catalogues; check the awarding institution before applying.</p>
            <div class="oe-platform-links">
            <a href="https://www.distancelearningportal.com/" target="_blank" rel="noopener noreferrer">
            <b>DistanceLearningPortal</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.coursera.org/" target="_blank" rel="noopener noreferrer">
            <b>Coursera</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.edx.org/" target="_blank" rel="noopener noreferrer">
            <b>edX</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-programmes" data-level="Online Degree">Explore degree options on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">07 · COUNTRY COMPARISON</span>
            <h3>Compare countries</h3>
            <p>Start a destination search, then compare programme availability and costs using current official sources.</p>
            <div class="oe-platform-links">
            <a href="https://www.studyportals.com/" target="_blank" rel="noopener noreferrer">
            <b>Studyportals</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-universities">Explore country filters on EduConnect <span>→</span>
            </a>
            </article>
          <article class="oe-platform-card">
            <span class="oe-platform-photo" aria-hidden="true">
            </span>
            <span class="oe-platform-kicker">08 · UNIVERSITY COMPARISON</span>
            <h3>Compare universities</h3>
            <p>Explore institution information and rankings where published, and review each programme on its official page.</p>
            <div class="oe-platform-links">
            <a href="https://www.studyportals.com/" target="_blank" rel="noopener noreferrer">
            <b>Studyportals</b>
            <span>Official site ↗</span>
            </a>
            <a href="https://www.topuniversities.com/" target="_blank" rel="noopener noreferrer">
            <b>QS TopUniversities</b>
            <span>Official site ↗</span>
            </a>
            </div>
            <a class="oe-platform-local" href="#oe-universities">Compare institutions on EduConnect <span>→</span>
            </a>
            </article>
        </div>
            <p class="oe-platform-note">EduConnect links to external discovery resources; courses and programmes remain hosted and managed by their respective providers. These suggestions follow your platform guide; they are not a ranking or endorsement.</p>
            </div>
            </section>
        <section class="oe-section oe-explorer" id="oe-programmes">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">DISCOVER &amp; COMPARE</p>
            <h2>Find online courses and degree programmes</h2>
            <p>Compare online courses, online degrees and distance-learning options by subject, qualification and study mode. Listings are illustrative; verify details directly with each provider.</p>
            </div>
            <div class="oe-explorer-actions">
            <button class="oe-button oe-outline oe-filter-toggle" type="button" aria-expanded="false">Filters</button>
            <button class="oe-button oe-outline" id="oe-clear">Clear all</button>
            </div>
            </div>
            <div class="oe-search-card">
            <div>
            <p class="oe-eyebrow">START YOUR SEARCH</p>
            <h2>Find learning that fits your goals</h2>
            <p>Search a sample of discovery links and illustrative options.</p>
            </div>
            <form id="oe-search-form" class="oe-search-form">
            <label class="oe-field oe-search-wide">
            <span>Course, subject or programme</span>
            <input id="oe-query" type="search" placeholder="e.g. data science, MBA, grade 8 maths">
            </label>
            <label class="oe-field">
            <span>Education level</span>
            <select id="oe-search-level">
            <option value="">Any level</option>${levels.map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Study mode</span>
            <select id="oe-search-mode">
            <option value="">Any mode</option>${["Fully online","Distance learning","Hybrid","On-campus","Self-paced online"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Country / destination</span>
            <select id="oe-search-country">
            <option value="">Any destination</option>${["India","United States","United Kingdom","Canada","Australia","Germany","Ireland","France","Netherlands"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Maximum budget</span>
            <select id="oe-search-budget">
            <option value="">Any budget</option>
            <option value="free">Free</option>
            <option value="10000">Under ₹10,000</option>
            <option value="50000">₹10,000–₹50,000</option>
            <option value="100000">₹50,000–₹1 lakh</option>
            <option value="500000">₹1 lakh–₹5 lakh</option>
            <option value="500001">Above ₹5 lakh</option>
            </select>
            </label>
            <button class="oe-button oe-primary oe-submit" type="submit">Search programmes <span>→</span>
            </button>
            </form>
            <p class="oe-data-note">Budget choices are search preferences. Sample listings do not include verified price data.</p>
            </div>
            <div class="oe-explorer-layout">
            <aside class="oe-filters" id="oe-filters" aria-label="Programme filters">
            <div class="oe-filter-heading">
            <h3>Filter programmes</h3>
            <button id="oe-clear-mobile" type="button">Clear</button>
            </div>
            <label class="oe-field">
            <span>Education level</span>
            <select id="oe-filter-level">
            <option value="">All levels</option>${levels.map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Study mode</span>
            <select id="oe-filter-mode">
            <option value="">All study modes</option>${["Fully online","Distance learning","Hybrid","On-campus","Self-paced online","Scheduled online"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Country</span>
            <select id="oe-filter-country">
            <option value="">All destinations</option>${["India","United States","United Kingdom","Canada","Australia","Germany","Ireland","France","Netherlands","Global"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Provider type</span>
            <select id="oe-filter-type">
            <option value="">All provider types</option>${["School","College","University","Online learning platform","Professional training provider"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Subject area</span>
            <select id="oe-filter-subject">
            <option value="">All subjects</option>${["Computer Science & IT","Artificial Intelligence","Data Science","Business & Management","Engineering & Technology","Medicine & Healthcare","Education","Arts & Humanities","Law","Finance & Accounting","Psychology","Science & Mathematics","Design & Media","Languages","Social Sciences","Marketing","Cybersecurity","Project Management"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Difficulty</span>
            <select id="oe-filter-difficulty">
            <option value="">Any level</option>
            <option>Beginner</option>
            <option>Intermediate</option>
            <option>Advanced</option>
            </select>
            </label>
            <label class="oe-field">
            <span>Budget preference</span>
            <select id="oe-filter-budget">
            <option value="">Any budget</option>
            <option value="free">Free</option>
            <option value="10000">Under ₹10,000</option>
            <option value="50000">₹10,000–₹50,000</option>
            <option value="100000">₹50,000–₹1 lakh</option>
            <option value="500000">₹1 lakh–₹5 lakh</option>
            <option value="500001">Above ₹5 lakh</option>
            </select>
            </label>
            <div class="oe-filter-disclaimer">Price ranges are preferences only. Unknown fees are never estimated.</div>
            </aside>
            <div class="oe-results">
            <div class="oe-results-toolbar">
            <p id="oe-result-count" aria-live="polite">Loading discovery options…</p>
            <label class="oe-sort">
            <span>Sort by</span>
            <select id="oe-sort">
            <option value="relevance">Relevance</option>
            <option value="lowest">Lowest tuition</option>
            <option value="highest">Highest tuition</option>
            <option value="shortest">Shortest duration</option>
            <option value="longest">Longest duration</option>
            <option value="name">Programme name</option>
            </select>
            </label>
            </div>
            <div class="oe-active-filters" id="oe-active-filters">
            </div>
            <div class="oe-programme-grid" id="oe-programme-results" aria-live="polite">
            </div>
            <div class="oe-empty" id="oe-empty" hidden>
            <span>⌕</span>
            <h3>No matching options yet</h3>
            <p>Try a broader search or clear some filters.</p>
            <button type="button" class="oe-button oe-primary" id="oe-empty-reset">Reset filters</button>
            </div>
            <button class="oe-button oe-outline oe-load-more" id="oe-load-more" type="button" hidden>Load more options</button>
            </div>
            </div>
            </div>
            </section>
        <section class="oe-section" id="oe-degrees">
            <div class="oe-container oe-feature-band">
            <div>
            <p class="oe-eyebrow">ACADEMIC PATHWAYS</p>
            <h2>Explore online degree options</h2>
            <p>Degree titles, delivery, admission criteria, recognition and fees vary by institution. Check every detail on the official university page.</p>
            </div>
            <div class="oe-degree-links">${["Bachelor’s degree","Master’s degree","MBA","Doctoral study"].map(x=>`<a href="#oe-programmes" data-level="${x===`Bachelor’s degree`?"Bachelor's":x===`Master’s degree`?"Master's":x===`Doctoral study`?"PhD / Doctorate":"MBA"}">
            <span>Explore pathway</span>
            <b>${x} →</b>
            </a>`).join("")}</div>
            </div>
            </section>
        <section class="oe-section oe-school" id="oe-school">
            <div class="oe-container oe-school-layout">
            <div>
            <p class="oe-eyebrow">LEARNING STARTS EARLY</p>
            <h2>School learning, at your pace</h2>
            <p>Find subject practice and learning resources for different stages. Open resources and practice material are not formal school qualifications.</p>
            <a class="oe-button oe-primary" href="#oe-programmes" data-subject="Science & Mathematics">Explore school resources →</a>
            </div>
            <div class="oe-school-grid">${[["Primary school","Foundational learning"],["Middle school","Build core subject skills"],["Secondary school","Explore advanced topics"],["Mathematics","Practice and problem solving"],["Science","Explore scientific ideas"],["English & languages","Reading, writing and language"],["Computer fundamentals","Digital skills and computing"],["Exam preparation","Structured revision resources"]].map(([x,y])=>`<a href="#oe-programmes" data-level="School">
            <b>${x}</b>
            <span>${y} →</span>
            </a>`).join("")}</div>
            </div>
            </section>
        <section class="oe-section oe-universities" id="oe-universities">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">INSTITUTION DISCOVERY</p>
            <h2>Explore universities and providers</h2>
            <p>Official institution links, checked 9 October 2026. Programme availability and recognition are programme-specific; verify directly.</p>
            </div>
            </div>
            <div class="oe-institution-filters">
            <label class="oe-field">
            <span>Country</span>
            <select id="oe-inst-country">
            <option value="">All countries</option>${[...new Set(onlineEducationInstitutions.map(x=>x.country))].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Programme level</span>
            <select id="oe-inst-level">
            <option value="">All levels</option>${["Bachelor's","Master's","Certificate","Diploma","Short Course"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Subject</span>
            <select id="oe-inst-subject">
            <option value="">All subjects</option>${[...new Set(onlineEducationInstitutions.flatMap(x=>x.subjects))].sort().map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <label class="oe-field">
            <span>Delivery mode</span>
            <select id="oe-inst-mode">
            <option value="">Any mode</option>${["Fully online","Distance learning","Hybrid"].map(x=>`<option>${x}</option>`).join("")}</select>
            </label>
            <button type="button" id="oe-inst-clear" class="oe-button oe-outline">Clear filters</button>
            </div>
            <div class="oe-provider-grid" id="oe-institution-results">${onlineEducationInstitutions.map(x=>`<article class="oe-provider-card oe-institution-card" data-country="${x.country}" data-levels="${x.levels.join("|")}" data-subjects="${x.subjects.join("|")}" data-modes="${x.modes.join("|")}">
            <div class="oe-institution-top">
            <span class="oe-institution-monogram" aria-hidden="true">${x.name.split(" ").filter(y=>/^[A-Z]/.test(y)).slice(0,2).map(y=>y[0]).join("")}</span>
            <span class="oe-verified-source">Official site</span>
            </div>
            <h3>${x.name}</h3>
            <p class="oe-institution-location">${x.city} · ${x.country} · ${x.type}</p>
            <p>${x.programmeNote}</p>
            <div class="oe-institution-tags">${x.levels.slice(0,3).map(y=>`<span>${y}</span>`).join("")}</div>
            <div class="oe-institution-actions">
            <a href="${x.url}" target="_blank" rel="noopener noreferrer">View institution ↗</a>
            <label>
            <input type="checkbox" data-institution-compare="${x.id}"> Compare</label>
            </div>
            <small>Source checked ${x.lastVerifiedAt}</small>
            </article>`).join("")}</div>
            <p id="oe-institution-empty" class="oe-institution-empty" hidden>No institutions match these filters. Clear one or more selections.</p>
            <div id="oe-institution-compare-bar" class="oe-institution-compare-bar" hidden>
            <span id="oe-institution-compare-count">0 selected</span>
            <button type="button" class="oe-button oe-outline" id="oe-inst-compare-clear">Clear</button>
            <button type="button" class="oe-button oe-primary" id="oe-inst-compare-show" disabled>Compare institutions</button>
            </div>
            </div>
            </section>
        <section class="oe-section oe-comparison-info" id="oe-compare">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">MAKE AN INFORMED CHOICE</p>
            <h2>Online, hybrid or on-campus?</h2>
            <p>The experience depends on the institution and specific programme. Confirm details before applying.</p>
            </div>
            </div>
            <div class="oe-table-wrap">
            <table class="oe-study-table">
            <thead>
            <tr>
            <th scope="col">Consideration</th>
            <th scope="col">Online / distance</th>
            <th scope="col">Hybrid</th>
            <th scope="col">On-campus</th>
            </tr>
            </thead>
            <tbody>${[["Flexibility","May offer flexible schedules; check format","Mix of online and in-person elements","Often follows a campus timetable"],["Campus attendance","May not be required; verify programme","Some attendance may be required","Usually includes campus attendance"],["Tuition & additional costs","Compare total and recurring fees","Check tuition and travel needs","Check tuition, housing and other costs"],["Instructor interaction","Format varies by provider","Online and in-person formats vary","Often includes in-person sessions"],["Duration & assessment","Check the programme details","Check delivery and assessment schedule","Check course structure and assessment"],["Networking","Online community varies","Can include online and campus contact","Campus-based opportunities vary"],["Recognition & eligibility","Verify with institution and regulator","Verify specific award and requirements","Verify specific award and requirements"]].map(row=>`<tr>${row.map(x=>`<td>${x}</td>`).join("")}</tr>`).join("")}</tbody>
            </table>
            </div>
            </div>
            </section>
        <section class="oe-section oe-pathways" id="oe-pathways">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">A PLACE TO BEGIN</p>
            <h2>Explore learning pathways</h2>
            <p>Curated topic suggestions for discovery, not a promise of a qualification or employment outcome.</p>
            </div>
            </div>
            <div class="oe-path-grid">${[["Beginner to software development","Computer Science"],["Foundations to data analysis","Data Science"],["AI & machine learning fundamentals","Artificial Intelligence"],["Digital marketing career discovery","Marketing"],["Business & management","Business & Management"],["Cybersecurity foundations","Cybersecurity"],["Academic progression to a degree","Bachelor's"]].map(([x,filter],i)=>`<a href="#oe-programmes" ${filter==="Bachelor's"?`data-level="${filter}"`:`data-subject="${filter}"`}>
            <span>0${i+1}</span>
            <b>${x}</b>
            <i>Explore →</i>
            </a>`).join("")}</div>
            </div>
            </section>
        <section class="oe-section oe-afford" id="oe-affordability">
            <div class="oe-container oe-afford-card">
            <div>
            <p class="oe-eyebrow">PLAN WITH CLARITY</p>
            <h2>Understand affordability</h2>
            <p>Compare published tuition in its original currency and fee period. Scholarships and financial aid depend on official eligibility rules and availability.</p>
            </div>
            <div class="oe-afford-links">
            <a href="#oe-programmes">Compare programme costs <span>→</span>
            </a>
            <a href="https://www.khanacademy.org/" target="_blank" rel="noopener noreferrer">Explore free learning resources <span>↗</span>
            </a>
            <a href="https://www.coursera.org/financial-aid" target="_blank" rel="noopener noreferrer">Check provider financial-aid information <span>↗</span>
            </a>
            </div>
            </div>
            </section>
        <section class="oe-section oe-how" id="oe-resources">
            <div class="oe-container">
            <div class="oe-section-head">
            <div>
            <p class="oe-eyebrow">THE EDUCONNECT APPROACH</p>
            <h2>How discovery works</h2>
            <p>Use EduConnect to explore options, then confirm programme details with the source.</p>
            </div>
            </div>
            <div class="oe-steps">${[["01","Discover","Explore programmes and learning resources."],["02","Filter","Narrow choices by goals, level, budget and study mode."],["03","Compare","Review the details that matter to you."],["04","Verify","Visit the official provider to confirm details or apply."]].map(([n,x,y])=>`<article>
            <span>${n}</span>
            <h3>${x}</h3>
            <p>${y}</p>
            </article>`).join("")}</div>
            </div>
            </section>
        <section class="oe-section oe-faq" id="oe-faq">
            <div class="oe-container oe-faq-layout">
            <div>
            <p class="oe-eyebrow">GOOD QUESTIONS, CLEAR ANSWERS</p>
            <h2>Online education FAQ</h2>
            <p>Always verify specific programme details with the institution or provider.</p>
            </div>
            <div class="oe-faq-list">${[["What is online education?","Learning delivered partly or fully through digital tools. The teaching, assessment and support format depends on the provider."],["What is the difference between an online course and an online degree?","A course may teach a focused subject and may offer a certificate. A degree is a formal academic qualification awarded by an institution after completing its requirements."],["Can I earn a Bachelor’s or Master’s degree online?","Some institutions offer online degree programmes. Check the institution’s official course page for format, eligibility, fees and award details."],["Are online degrees recognized?","Recognition depends on the awarding institution, programme and jurisdiction. Check with the relevant official regulator or recognition authority."],["How can I compare tuition fees?","Compare amounts in the original currency and note whether each fee is total, annual or per term. Include additional costs where published."],["Can I study for free online?","Some platforms publish free learning resources or course access. Certificates, assessments or other services may have separate costs; confirm with the provider."],["What is distance learning?","Study delivered with learners and instructors separated by location. It can include online, print or other learning materials."],["What is the difference between online, hybrid and on-campus study?","Online learning is primarily remote, hybrid combines remote and in-person elements, and on-campus study typically involves attendance at a physical campus. Exact formats vary."],["How do I compare universities?","Review official programme details, entry requirements, delivery, tuition and recognition. Consult relevant official regulators for recognition checks."],["How can I check whether a programme is legitimate?","Confirm the awarding institution and programme through official institution pages and the relevant education regulator or recognition database."]].map(([q,a],i)=>`<details ${i===0?"":""}>
            <summary>${q}<span aria-hidden="true">+</span>
            </summary>
            <p>${a}</p>
            </details>`).join("")}</div>
            </div>
            </section>
        <section class="oe-final-cta" id="oe-final">
            <div class="oe-container">
            <p class="oe-eyebrow">YOUR NEXT CHAPTER</p>
            <h2>Your Next Learning Opportunity Starts Here.</h2>
            <p>Discover courses, compare programmes and find a learning path that fits your ambitions.</p>
            <a class="oe-button oe-light-button" href="#oe-programmes">Explore Programmes <span>→</span>
            </a>
            </div>
            </section>
      </main>`;
}

