package com.ALL_in_one.config;

import com.ALL_in_one.security.CustomUserDetailsService;
import com.ALL_in_one.service.JwtService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.security.core.userdetails.UserDetails;

import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;

import org.springframework.stereotype.Component;

import org.springframework.web.filter.OncePerRequestFilter;


import java.io.IOException;


@Component
public class JwtAuthenticationFilter
        extends OncePerRequestFilter {


    private final JwtService jwtService;

    private final CustomUserDetailsService userDetailsService;


    public JwtAuthenticationFilter(

            JwtService jwtService,

            CustomUserDetailsService userDetailsService

    ) {

        this.jwtService =
                jwtService;

        this.userDetailsService =
                userDetailsService;

    }


    @Override
    protected void doFilterInternal(

            HttpServletRequest request,

            HttpServletResponse response,

            FilterChain filterChain

    )
            throws ServletException, IOException {


        String authorizationHeader =
                request.getHeader(
                        "Authorization"
                );


        /* -------------------------------------------------
           NO TOKEN
        ------------------------------------------------- */

        if (
                authorizationHeader == null
                        ||
                        !authorizationHeader.startsWith(
                                "Bearer "
                        )
        ) {

            filterChain.doFilter(
                    request,
                    response
            );

            return;

        }


        String token =
                authorizationHeader.substring(
                        7
                );


        String email;


        /* -------------------------------------------------
           READ TOKEN
        ------------------------------------------------- */

        try {

            email =
                    jwtService.extractEmail(
                            token
                    );

        }
        catch (Exception exception) {

            filterChain.doFilter(
                    request,
                    response
            );

            return;

        }


        /* -------------------------------------------------
           AUTHENTICATE USER
        ------------------------------------------------- */

        if (
                email != null
                        &&
                        SecurityContextHolder
                                .getContext()
                                .getAuthentication()
                                == null
        ) {


            UserDetails userDetails =
                    userDetailsService
                            .loadUserByUsername(
                                    email
                            );


            if (
                    jwtService.isTokenValid(
                            token,
                            email
                    )
            ) {


                UsernamePasswordAuthenticationToken authentication =

                        new UsernamePasswordAuthenticationToken(

                                userDetails,

                                null,

                                userDetails.getAuthorities()

                        );


                authentication.setDetails(

                        new WebAuthenticationDetailsSource()
                                .buildDetails(
                                        request
                                )

                );


                SecurityContextHolder
                        .getContext()
                        .setAuthentication(
                                authentication
                        );

            }

        }


        filterChain.doFilter(
                request,
                response
        );

    }

}